from alireza import (
    UsefulTools,DjangoTools,
)